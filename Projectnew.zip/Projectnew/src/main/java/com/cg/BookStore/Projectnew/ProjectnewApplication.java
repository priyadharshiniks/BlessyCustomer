package com.cg.BookStore.Projectnew;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectnewApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectnewApplication.class, args);
	}

}
